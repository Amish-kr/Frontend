
function Date({ date }) {
  return (
    <div className='datecontainer'>
      {/* <div className="datesubcontainer">
        <p>{date}</p>
        <button>Add to Calendar</button>
      </div> */}
      <span>
        (GMT+5:30) india standard time (Asia/Kolkata)
      </span>
    </div>
  )
}

export default Date