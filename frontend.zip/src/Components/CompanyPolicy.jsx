import React from "react";
import "./PolicyMaster.css";

function CompanyPolicy() {
  return (
    <div>
      <ul className='list-elements-container'>
        <li className='list-elements-text'>
          Lorem ipsum dolor sit amet consectetur. Penatibus cursus elit sem
          imperdiet pretium a semper adipiscing pellentesque. Felis eget iaculis
          est scelerisque ut velit rhoncus. Facilisi neque a volutpat et. Tellus
          etiam potenti pulvinar vulputate ipsum viverra magna.Lorem ipsum dolor
          sit amet consectetur. Penatibus cursus elit sem imperdiet pretium a
          semper adipiscing pellentesque. Felis eget iaculis est scelerisque ut
          velit rhoncus. Facilisi neque a volutpat et. Tellus etiam potenti
          pulvinar vulputate ipsum viverra magna.
        </li>
        <li className='list-elements-text'>
          Lorem ipsum dolor sit amet consectetur. Penatibus cursus elit sem
          imperdiet pretium a semper adipiscing pellentesque. Felis eget iaculis
          est scelerisque ut velit rhoncus. Facilisi neque a volutpat et. Tellus
          etiam potenti pulvinar vulputate ipsum viverra magna.Lorem ipsum dolor
          sit amet consectetur. Penatibus cursus elit sem imperdiet pretium a
          semper adipiscing pellentesque. Felis eget iaculis est scelerisque ut
          velit rhoncus. Facilisi neque a volutpat et. Tellus etiam potenti
          pulvinar vulputate ipsum viverra magna.
        </li>
        <li className='list-elements-text'>
          Lorem ipsum dolor sit amet consectetur. Penatibus cursus elit sem
          imperdiet pretium a semper adipiscing pellentesque. Felis eget iaculis
          est scelerisque ut velit rhoncus. Facilisi neque a volutpat et. Tellus
          etiam potenti pulvinar vulputate ipsum viverra magna.Lorem ipsum dolor
          sit amet consectetur. Penatibus cursus elit sem imperdiet pretium a
          semper adipiscing pellentesque. Felis eget iaculis est scelerisque ut
          velit rhoncus. Facilisi neque a volutpat et. Tellus etiam potenti
          pulvinar vulputate ipsum viverra magna.
        </li>
      </ul>
    </div>
  )
}

export default CompanyPolicy
