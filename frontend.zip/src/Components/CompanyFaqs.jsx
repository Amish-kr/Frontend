import React from "react";
import "./PolicyMaster.css";

function CompanyFaqs() {
  return (
    <div>
      
      <ul className='list-elements-container'>
        <li className='list-elements-text'>FAQ 1</li>
        <li className='list-elements-text'>FAQ 2</li>
        <li className='list-elements-text'>FAQ 3</li>
      </ul>
    </div>
    
  )
}

export default CompanyFaqs
