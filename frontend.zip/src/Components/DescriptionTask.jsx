import React from 'react'

function DescriptionTask({ text }) {
  return (
    <div className='descriptiontaskcontainer'>
      <p> {text}</p>
    </div >
  )
}

export default DescriptionTask