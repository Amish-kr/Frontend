import MyNotification from '../Components/MyNotification';

const Noti = () => {
  return (
    <div>
      <MyNotification />
    </div>
  );
}

export default Noti;
