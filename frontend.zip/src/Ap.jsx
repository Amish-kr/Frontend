import './Ap.css'
import BadgeForm from './Components/BadgeForm'
import './Components/footer'

function Ap() {

  return (
    <div className='App'>
      <BadgeForm/>
    </div>
  )
}

export default Ap
