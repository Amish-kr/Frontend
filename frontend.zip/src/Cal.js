import './Cal.css';

import Calendar from "./Components/calendar/Calendar";


function Cal() {
  return (
    <div >
      
      <Calendar></Calendar>
    </div>
  );
}

export default Cal;