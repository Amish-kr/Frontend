export const flow = [
    {
        id: 1,
        name: 'John',
        age: 25,
        email: "john@email.com",
    },
    {
        id: 2,
        name: 'Jane',
        age: 24,
        email: "jane@email.com",
    },
    {
        id: 3,
        name: 'Bob',
        age: 26,
        email: "bob@email.com",
    },
    {
        id: 4,
        name: 'Mike',
        age: 27,
        email: "mike@email.com",
    },
    {
        id: 5,
        name: 'Mary',
        age: 28,
        email: "mary@email.com",
    },
    {
        id: 6,
        name: 'Sue',
        age: 29,
        email: "sue@email.com",
    },
    {
        id: 7,
        name: 'Tom',
        age: 30,
        email: "tom@email.com",
    },
    {
        id: 8,
        name: 'Tim',
        age: 31,
        email: "tim@email.com",
    }
]