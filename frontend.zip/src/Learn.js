import Tabs from "./Components/Tabs"
import "../src/Components/Tabs.css"

function Learn() {
  return (
    <div className='aa-2'>
      <div className='aa-1'>
        <Tabs />
      </div>
    </div> 
  ) 
}

export default Learn

